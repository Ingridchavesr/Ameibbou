const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const authMiddleware = require('../middlewares/authMiddleware');

const usuarioValidation = require('../validations/usuarioValidation');
const validarCampos = require('../middlewares/validarCampos');

// ENV
require('dotenv').config();

// Função utilitária para gerar token JWT
function gerarToken(payload) {
    return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });
}

// Rota de criação de usuário
router.post('/usuarios', usuarioValidation, validarCampos, async (req, res) => {
    const { nome_usuario, idade, email, senha_usuario, id_responsavel } = req.body;

    try {
        if (!senha_usuario) return res.status(400).json({ message: 'Senha é obrigatória' });

        // Verifica se o e-mail já existe
        const verificarEmail = 'SELECT * FROM usuario WHERE email = ?';
        db.query(verificarEmail, [email], async (err, results) => {
            if (err) return res.status(500).json({ message: 'Erro ao verificar e-mail', error: err });
            if (results.length > 0) return res.status(400).json({ message: 'E-mail já cadastrado' });

            const senhaCriptografada = await bcrypt.hash(senha_usuario, 10);
            const sql = 'INSERT INTO usuario (nome_usuario, idade, email, senha_usuario, id_responsavel) VALUES (?, ?, ?, ?, ?)';
            db.query(sql, [nome_usuario, idade, email, senhaCriptografada, id_responsavel], (err, result) => {
                if (err) return res.status(500).json(err);
                res.status(201).json({ id: result.insertId, message: 'Usuário criado com sucesso' });
            });
        });
    } catch (error) {
        res.status(500).json({ message: 'Erro ao criar usuário', error });
    }
});

// Rota de login de usuário
router.post('/login', (req, res) => {
    const { email, senha_usuario } = req.body;

    if (!email || !senha_usuario) {
        return res.status(400).json({ message: 'Email e senha são obrigatórios' });
    }

    const sql = 'SELECT * FROM usuario WHERE email = ?';
    db.query(sql, [email], async (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.length === 0) return res.status(401).json({ message: 'Usuário não encontrado' });

        const usuario = results[0];

        if (!usuario.senha_usuario) {
            return res.status(500).json({ message: 'Senha inválida no banco de dados.' });
        }

        const senhaCorreta = await bcrypt.compare(senha_usuario, usuario.senha_usuario);
        if (!senhaCorreta) return res.status(401).json({ message: 'Senha incorreta' });

        const token = gerarToken({
            id: usuario.id_usuario,
            email: usuario.email,
            tipo: 'usuario'
        });

        res.json({ message: 'Login bem-sucedido', token });
    });
});

// Rota protegida para buscar dados do usuário autenticado
router.get('/usuarios', authMiddleware, (req, res) => {
    db.query('SELECT id_usuario, nome_usuario, email FROM usuario WHERE id_usuario = ?', [req.userId], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.length === 0) return res.status(404).json({ message: 'Usuário não encontrado' });
        res.json(results[0]);
    });
});

module.exports = router;