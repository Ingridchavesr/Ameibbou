const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validação para personagens
const validatePersonagem = [
  body('nome').notEmpty().withMessage('Nome é obrigatório'),
  body('id_usuario').isInt({ gt: 0 }).withMessage('ID do usuário deve ser um número inteiro positivo'),
];

// Criar personagem (com validação)
router.post('/personagens', validatePersonagem, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { nome, id_usuario } = req.body;
  const sql = 'INSERT INTO usuario_personagem (nome, id_usuario) VALUES (?, ?)';
  db.query(sql, [nome, id_usuario], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Personagem criado com sucesso' });
  });
});

// Listar todos os personagens (rota protegida)
router.get('/personagens', authMiddleware, (req, res) => {
  db.query('SELECT * FROM usuario_personagem', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar personagem por ID (rota protegida)
router.get('/personagens/:id', authMiddleware, (req, res) => {
  db.query('SELECT * FROM usuario_personagem WHERE id_personagem = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Personagem não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar personagem (com validação e rota protegida)
router.put('/personagens/:id', authMiddleware, validatePersonagem, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { nome, id_usuario } = req.body;
  const sql = 'UPDATE usuario_personagem SET nome = ?, id_usuario = ? WHERE id_personagem = ?';
  db.query(sql, [nome, id_usuario, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Personagem atualizado com sucesso' });
  });
});

// Deletar personagem (rota protegida)
router.delete('/personagens/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM usuario_personagem WHERE id_personagem = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Personagem deletado com sucesso' });
  });
});

module.exports = router;
