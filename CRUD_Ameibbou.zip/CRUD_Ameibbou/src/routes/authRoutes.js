const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Login - Responsável ou Usuário
router.post('/login', (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ mensagem: 'E-mail e senha são obrigatórios.' });
  }

  // Tenta autenticar como usuário
  db.query('SELECT * FROM usuario WHERE email = ?', [email], (err, usuarioResult) => {
    if (err) return res.status(500).json({ erro: err });

    if (usuarioResult.length > 0) {
      const usuario = usuarioResult[0];
      return autenticarUsuario(usuario, 'usuario', 'senha_usuario', 'id_usuario', res, senha);
    }

    // Tenta autenticar como responsável
    db.query('SELECT * FROM responsavel WHERE email = ?', [email], (err2, responsavelResult) => {
      if (err2) return res.status(500).json({ erro: err2 });

      if (responsavelResult.length === 0) {
        return res.status(401).json({ mensagem: 'E-mail não encontrado.' });
      }

      const responsavel = responsavelResult[0];
      return autenticarUsuario(responsavel, 'responsavel', 'senha_responsavel', 'id_responsavel', res, senha);
    });
  });
});

// Função auxiliar para autenticar usuário ou responsável
function autenticarUsuario(entidade, tipo, campoSenha, campoId, res, senhaDigitada) {
  bcrypt.compare(senhaDigitada, entidade[campoSenha], (err, isMatch) => {
    if (err || !isMatch) {
      return res.status(401).json({ mensagem: 'Senha incorreta.' });
    }

    const payload = { id: entidade[campoId], tipo };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ token, tipo, id: entidade[campoId] });
  });
}

module.exports = router;