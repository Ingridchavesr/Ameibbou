const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validação dos campos para progresso_jogo
const validateProgresso = [
  body('id_usuario').isInt({ gt: 0 }).withMessage('id_usuario deve ser um número inteiro positivo'),
  body('id_jogo').isInt({ gt: 0 }).withMessage('id_jogo deve ser um número inteiro positivo'),
  body('nivel_atual').isInt({ min: 0 }).withMessage('nivel_atual deve ser um número inteiro maior ou igual a zero'),
  body('pontuacao').isInt({ min: 0 }).withMessage('pontuacao deve ser um número inteiro maior ou igual a zero'),
  body('ultima_jogada').isISO8601().withMessage('ultima_jogada deve ser uma data válida'),
];

// Criar progresso_jogo (com validação)
router.post('/progresso_jogo', validateProgresso, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada } = req.body;
  const sql = 'INSERT INTO progresso_jogo (id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Progresso de jogo criado com sucesso' });
  });
});

// Listar todos os progressos (protegido)
router.get('/progresso_jogo', authMiddleware, (req, res) => {
  db.query('SELECT * FROM progresso_jogo', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar progresso por ID (protegido)
router.get('/progresso_jogo/:id', authMiddleware, (req, res) => {
  db.query('SELECT * FROM progresso_jogo WHERE id_progresso = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Progresso não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar progresso (validação + protegido)
router.put('/progresso_jogo/:id', authMiddleware, validateProgresso, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada } = req.body;
  const sql = 'UPDATE progresso_jogo SET id_usuario = ?, id_jogo = ?, nivel_atual = ?, pontuacao = ?, ultima_jogada = ? WHERE id_progresso = ?';
  db.query(sql, [id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Progresso atualizado com sucesso' });
  });
});

// Deletar progresso (protegido)
router.delete('/progresso_jogo/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM progresso_jogo WHERE id_progresso = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Progresso deletado com sucesso' });
  });
});

module.exports = router;