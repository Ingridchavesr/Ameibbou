const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validação dos dados de entrada
const validateJogo = [
  body('nome').isString().trim().notEmpty().withMessage('Nome é obrigatório'),
  body('descricao').isString().trim().notEmpty().withMessage('Descrição é obrigatória'),
];

// Criar novo jogo
router.post('/jogos', authMiddleware, validateJogo, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { nome, descricao } = req.body;
  const sql = 'INSERT INTO jogos (nome, descricao) VALUES (?, ?)';
  db.query(sql, [nome, descricao], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Jogo criado com sucesso' });
  });
});

// Buscar todos os jogos
router.get('/jogos', authMiddleware, (req, res) => {
  db.query('SELECT * FROM jogos', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar jogo por ID
router.get('/jogos/:id', authMiddleware, (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM jogos WHERE id_jogo = ?', [id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Jogo não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar jogo
router.put('/jogos/:id', authMiddleware, validateJogo, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { nome, descricao } = req.body;
  const id = req.params.id;
  const sql = 'UPDATE jogos SET nome = ?, descricao = ? WHERE id_jogo = ?';
  db.query(sql, [nome, descricao, id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Jogo atualizado com sucesso' });
  });
});

// Deletar jogo
router.delete('/jogos/:id', authMiddleware, (req, res) => {
  const id = req.params.id;
  db.query('DELETE FROM jogos WHERE id_jogo = ?', [id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Jogo deletado com sucesso' });
  });
});

module.exports = router;