const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validações
const validateControleParental = [
  body('id_usuario').isInt().withMessage('ID do usuário deve ser um número inteiro'),
  body('relatorios').isString().trim().notEmpty().withMessage('Relatórios são obrigatórios'),
  body('tempo_uso').isString().trim().notEmpty().withMessage('Tempo de uso é obrigatório'),
  body('permissoes').isString().trim().notEmpty().withMessage('Permissões são obrigatórias'),
];

// Criar controle parental
router.post('/controle_parental', authMiddleware, validateControleParental, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, relatorios, tempo_uso, permissoes } = req.body;
  const sql = 'INSERT INTO controle_parental (id_usuario, relatorios, tempo_uso, permissoes) VALUES (?, ?, ?, ?)';
  db.query(sql, [id_usuario, relatorios, tempo_uso, permissoes], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Controle parental criado com sucesso' });
  });
});

// Listar todos os controles parentais
router.get('/controle_parental', authMiddleware, (req, res) => {
  db.query('SELECT * FROM controle_parental', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar controle parental por ID
router.get('/controle_parental/:id', authMiddleware, (req, res) => {
  db.query('SELECT * FROM controle_parental WHERE id_controle = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Controle parental não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar controle parental
router.put('/controle_parental/:id', authMiddleware, validateControleParental, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, relatorios, tempo_uso, permissoes } = req.body;
  const sql = 'UPDATE controle_parental SET id_usuario = ?, relatorios = ?, tempo_uso = ?, permissoes = ? WHERE id_controle = ?';
  db.query(sql, [id_usuario, relatorios, tempo_uso, permissoes, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Controle parental atualizado com sucesso' });
  });
});

// Deletar controle parental
router.delete('/controle_parental/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM controle_parental WHERE id_controle = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Controle parental deletado com sucesso' });
  });
});

module.exports = router;