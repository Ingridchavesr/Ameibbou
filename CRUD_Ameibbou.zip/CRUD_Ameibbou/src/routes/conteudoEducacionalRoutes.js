const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validações
const validateConteudo = [
  body('tipo').isString().trim().notEmpty().withMessage('Tipo é obrigatório'),
  body('dificuldade').isString().trim().notEmpty().withMessage('Dificuldade é obrigatória'),
  body('descricao').isString().trim().notEmpty().withMessage('Descrição é obrigatória'),
];

// Criar conteúdo educacional
router.post('/conteudo_educacional', authMiddleware, validateConteudo, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { tipo, dificuldade, descricao } = req.body;
  const sql = 'INSERT INTO conteudo_educacional (tipo, dificuldade, descricao) VALUES (?, ?, ?)';
  db.query(sql, [tipo, dificuldade, descricao], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Conteúdo educacional criado com sucesso' });
  });
});

// Listar todos os conteúdos educacionais
router.get('/conteudo_educacional', authMiddleware, (req, res) => {
  db.query('SELECT * FROM conteudo_educacional', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar conteúdo por ID
router.get('/conteudo_educacional/:id', authMiddleware, (req, res) => {
  db.query('SELECT * FROM conteudo_educacional WHERE id_conteudo = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Conteúdo não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar conteúdo educacional
router.put('/conteudo_educacional/:id', authMiddleware, validateConteudo, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { tipo, dificuldade, descricao } = req.body;
  const sql = 'UPDATE conteudo_educacional SET tipo = ?, dificuldade = ?, descricao = ? WHERE id_conteudo = ?';
  db.query(sql, [tipo, dificuldade, descricao, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Conteúdo educacional atualizado com sucesso' });
  });
});

// Deletar conteúdo educacional
router.delete('/conteudo_educacional/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM conteudo_educacional WHERE id_conteudo = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Conteúdo educacional deletado com sucesso' });
  });
});

module.exports = router;

router.get('/conteudo_educacional/:id', (req, res) => {
    db.query('SELECT * FROM conteudo_educacional WHERE id_conteudo = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Conteúdo não encontrado' });
        res.json(result[0]);
    });
});

router.put('/conteudo_educacional/:id', (req, res) => {
    const { tipo, dificuldade, descricao } = req.body;
    const sql = 'UPDATE conteudo_educacional SET tipo = ?, dificuldade = ?, descricao = ? WHERE id_conteudo = ?';
    db.query(sql, [tipo, dificuldade, descricao, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Conteúdo atualizado com sucesso' });
    });
});

router.delete('/conteudo_educacional/:id', (req, res) => {
    db.query('DELETE FROM conteudo_educacional WHERE id_conteudo = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Conteúdo deletado com sucesso' });
    });
});

module.exports = router;