const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validação para criação e atualização de responsável
const validateResponsavel = [
  body('nome').notEmpty().withMessage('Nome é obrigatório'),
  body('email').isEmail().withMessage('Email inválido'),
  body('senha_responsavel').isLength({ min: 6 }).withMessage('Senha precisa ter pelo menos 6 caracteres'),
];

// Criar responsável (com validação e senha criptografada)
router.post('/responsaveis', validateResponsavel, async (req, res) => {
  // Verificar erros da validação
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { nome, email, senha_responsavel } = req.body;

  try {
    const senhaCriptografada = await bcrypt.hash(senha_responsavel, 10);
    const sql = 'INSERT INTO responsavel (nome, email, senha_responsavel) VALUES (?, ?, ?)';
    db.query(sql, [nome, email, senhaCriptografada], (err, result) => {
      if (err) return res.status(500).json(err);
      res.status(201).json({ id: result.insertId, message: 'Responsável criado com sucesso' });
    });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao criar responsável', error });
  }
});

// Listar todos os responsáveis (rota protegida)
router.get('/responsaveis', authMiddleware, (req, res) => {
  db.query('SELECT id_responsavel, nome, email FROM responsavel', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar responsável por ID (rota protegida)
router.get('/responsaveis/:id', authMiddleware, (req, res) => {
  db.query('SELECT id_responsavel, nome, email FROM responsavel WHERE id_responsavel = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Responsável não encontrado' });
    res.json(result[0]);
  });
});

// Atualizar responsável (com validação, senha criptografada e rota protegida)
router.put('/responsaveis/:id', authMiddleware, validateResponsavel, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { nome, email, senha_responsavel } = req.body;

  try {
    const senhaCriptografada = await bcrypt.hash(senha_responsavel, 10);
    const sql = 'UPDATE responsavel SET nome = ?, email = ?, senha_responsavel = ? WHERE id_responsavel = ?';
    db.query(sql, [nome, email, senhaCriptografada, req.params.id], (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Responsável atualizado com sucesso' });
    });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar responsável', error });
  }
});

// Deletar responsável (rota protegida)
router.delete('/responsaveis/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM responsavel WHERE id_responsavel = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Responsável deletado com sucesso' });
  });
});

module.exports = router;