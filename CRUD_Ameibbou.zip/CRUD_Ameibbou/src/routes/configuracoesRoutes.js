const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { body, validationResult } = require('express-validator');
const authMiddleware = require('../middlewares/authMiddleware');

// Validações
const validateConfiguracoes = [
  body('id_usuario').isInt().withMessage('ID do usuário deve ser um número inteiro'),
  body('tema').isString().trim().notEmpty().withMessage('Tema é obrigatório'),
  body('volume').isInt({ min: 0, max: 100 }).withMessage('Volume deve ser um número entre 0 e 100'),
  body('acessibilidade').isString().trim().notEmpty().withMessage('Acessibilidade é obrigatória'),
];

// Criar configuração
router.post('/configuracoes', authMiddleware, validateConfiguracoes, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, tema, volume, acessibilidade } = req.body;
  const sql = 'INSERT INTO configuracoes (id_usuario, tema, volume, acessibilidade) VALUES (?, ?, ?, ?)';
  db.query(sql, [id_usuario, tema, volume, acessibilidade], (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, message: 'Configuração criada com sucesso' });
  });
});

// Listar todas as configurações
router.get('/configuracoes', authMiddleware, (req, res) => {
  db.query('SELECT * FROM configuracoes', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Buscar configuração por ID
router.get('/configuracoes/:id', authMiddleware, (req, res) => {
  db.query('SELECT * FROM configuracoes WHERE id_conf = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Configuração não encontrada' });
    res.json(result[0]);
  });
});

// Atualizar configuração
router.put('/configuracoes/:id', authMiddleware, validateConfiguracoes, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id_usuario, tema, volume, acessibilidade } = req.body;
  const sql = 'UPDATE configuracoes SET id_usuario = ?, tema = ?, volume = ?, acessibilidade = ? WHERE id_conf = ?';
  db.query(sql, [id_usuario, tema, volume, acessibilidade, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Configuração atualizada com sucesso' });
  });
});

// Deletar configuração
router.delete('/configuracoes/:id', authMiddleware, (req, res) => {
  db.query('DELETE FROM configuracoes WHERE id_conf = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Configuração deletada com sucesso' });
  });
});

module.exports = router;