const { body } = require('express-validator');

const progressoJogoValidationRules = [
  body('id_usuario')
    .notEmpty().withMessage('ID do usuário é obrigatório')
    .isInt().withMessage('ID do usuário deve ser um número inteiro'),

  body('id_jogo')
    .notEmpty().withMessage('ID do jogo é obrigatório')
    .isInt().withMessage('ID do jogo deve ser um número inteiro'),

  body('nivel_atual')
    .notEmpty().withMessage('Nível atual é obrigatório')
    .isInt({ min: 0 }).withMessage('Nível atual deve ser um número inteiro maior ou igual a 0'),

  body('pontuacao')
    .notEmpty().withMessage('Pontuação é obrigatória')
    .isInt({ min: 0 }).withMessage('Pontuação deve ser um número inteiro maior ou igual a 0'),

  body('ultima_jogada')
    .notEmpty().withMessage('Data da última jogada é obrigatória')
    .isISO8601().withMessage('Data da última jogada deve estar no formato ISO 8601'),
];

module.exports = { progressoJogoValidationRules };