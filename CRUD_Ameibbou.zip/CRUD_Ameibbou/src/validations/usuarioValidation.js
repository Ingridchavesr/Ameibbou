const { body } = require('express-validator');

const usuarioValidationRules = [
  body('nome_usuario')
    .notEmpty().withMessage('Nome do usuário é obrigatório')
    .isLength({ min: 3 }).withMessage('Nome deve ter pelo menos 3 caracteres'),

  body('idade')
    .notEmpty().withMessage('Idade é obrigatória')
    .isInt({ min: 0 }).withMessage('Idade deve ser um número inteiro positivo'),

  body('email')
    .notEmpty().withMessage('Email é obrigatório')
    .isEmail().withMessage('Email inválido'),

  body('senha_usuario')
    .notEmpty().withMessage('Senha é obrigatória')
    .isLength({ min: 6 }).withMessage('Senha deve ter pelo menos 6 caracteres'),

  body('id_responsavel')
    .notEmpty().withMessage('ID do responsável é obrigatório')
    .isInt().withMessage('ID do responsável deve ser um número inteiro'),
];

module.exports = { usuarioValidationRules };