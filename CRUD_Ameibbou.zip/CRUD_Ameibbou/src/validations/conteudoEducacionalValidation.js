const { body } = require('express-validator');

const conteudoEducacionalValidationRules = [
  body('tipo')
    .notEmpty().withMessage('Tipo é obrigatório')
    .isIn(['jogo', 'video', 'texto']).withMessage('Tipo deve ser "jogo", "video" ou "texto"'),

  body('dificuldade')
    .notEmpty().withMessage('Dificuldade é obrigatória')
    .isIn(['facil', 'medio', 'dificil']).withMessage('Dificuldade deve ser "facil", "medio" ou "dificil"'),

  body('descricao')
    .notEmpty().withMessage('Descrição é obrigatória')
    .isLength({ min: 10 }).withMessage('Descrição deve ter pelo menos 10 caracteres'),
];

module.exports = { conteudoEducacionalValidationRules };