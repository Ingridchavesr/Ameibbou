const { body } = require('express-validator');

const configuracoesValidationRules = [
  body('id_usuario')
    .notEmpty().withMessage('ID do usuário é obrigatório')
    .isInt().withMessage('ID do usuário deve ser um número inteiro'),

  body('tema')
    .notEmpty().withMessage('Tema é obrigatório')
    .isIn(['claro', 'escuro']).withMessage('Tema deve ser "claro" ou "escuro"'),

  body('volume')
    .notEmpty().withMessage('Volume é obrigatório')
    .isInt({ min: 0, max: 100 }).withMessage('Volume deve ser um número inteiro entre 0 e 100'),

  body('acessibilidade')
    .notEmpty().withMessage('Acessibilidade é obrigatória')
    .isBoolean().withMessage('Acessibilidade deve ser true ou false'),
];

module.exports = { configuracoesValidationRules };