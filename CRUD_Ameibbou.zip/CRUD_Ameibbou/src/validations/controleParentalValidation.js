const { body } = require('express-validator');

const controleParentalValidationRules = [
  body('id_usuario')
    .notEmpty().withMessage('ID do usuário é obrigatório')
    .isInt().withMessage('ID do usuário deve ser um número inteiro'),

  body('relatorios')
    .notEmpty().withMessage('Relatórios são obrigatórios')
    .isLength({ min: 5 }).withMessage('Relatórios devem ter ao menos 5 caracteres'),

  body('tempo_uso')
    .notEmpty().withMessage('Tempo de uso é obrigatório')
    .isInt({ min: 0 }).withMessage('Tempo de uso deve ser um número inteiro maior ou igual a 0'),

  body('permissoes')
    .notEmpty().withMessage('Permissões são obrigatórias')
    .isLength({ min: 3 }).withMessage('Permissões devem ter ao menos 3 caracteres'),
];

module.exports = { controleParentalValidationRules };