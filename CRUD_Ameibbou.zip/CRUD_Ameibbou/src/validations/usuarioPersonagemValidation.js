const { body } = require('express-validator');

const usuarioPersonagemValidationRules = [
  body('nome')
    .notEmpty().withMessage('Nome do personagem é obrigatório')
    .isLength({ min: 3 }).withMessage('Nome do personagem deve ter ao menos 3 caracteres'),

  body('id_usuario')
    .notEmpty().withMessage('ID do usuário é obrigatório')
    .isInt().withMessage('ID do usuário deve ser um número inteiro'),
];

module.exports = { usuarioPersonagemValidationRules };