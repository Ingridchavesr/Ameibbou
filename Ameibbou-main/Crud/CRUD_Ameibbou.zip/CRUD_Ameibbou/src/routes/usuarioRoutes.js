const express = require('express');
const router = express.Router();
const db = require('../config/db');


router.post('/usuarios', (req, res) => {
    const { nome_usuario, idade, email, senha_usuario, id_responsavel } = req.body;
    const sql = 'INSERT INTO usuario (nome_usuario, idade, email, senha_usuario, id_responsavel) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [nome_usuario, idade, email, senha_usuario, id_responsavel], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Usuário criado com sucesso' });
    });
});


router.get('/usuarios', (req, res) => {
    db.query('SELECT * FROM usuario', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});


router.get('/usuarios/:id', (req, res) => {
    db.query('SELECT * FROM usuario WHERE id_usuario = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Usuário não encontrado' });
        res.json(result[0]);
    });
});


router.put('/usuarios/:id', (req, res) => {
    const { nome_usuario, idade, email, senha_usuario, id_responsavel } = req.body;
    const sql = 'UPDATE usuario SET nome_usuario = ?, idade = ?, email = ?, senha_usuario = ?, id_responsavel = ? WHERE id_usuario = ?';
    db.query(sql, [nome_usuario, idade, email, senha_usuario, id_responsavel, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Usuário atualizado com sucesso' });
    });
});


router.delete('/usuarios/:id', (req, res) => {
    db.query('DELETE FROM usuario WHERE id_usuario = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Usuário deletado com sucesso' });
    });
});

module.exports = router;