const express = require('express');
const router = express.Router();
const db = require('../config/db');

// CREATE - Criar nova configuração
router.post('/configuracoes', (req, res) => {
    const { id_usuario, tema, volume, acessibilidade } = req.body;
    const sql = 'INSERT INTO configuracoes (id_usuario, tema, volume, acessibilidade) VALUES (?, ?, ?, ?)';
    db.query(sql, [id_usuario, tema, volume, acessibilidade], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Configuração criada com sucesso' });
    });
});

// READ - Listar todas as configurações
router.get('/configuracoes', (req, res) => {
    db.query('SELECT * FROM configuracoes', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// READ - Obter configuração por ID
router.get('/configuracoes/:id', (req, res) => {
    db.query('SELECT * FROM configuracoes WHERE id_conf = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Configuração não encontrada' });
        res.json(result[0]);
    });
});

// UPDATE - Atualizar configuração
router.put('/configuracoes/:id', (req, res) => {
    const { id_usuario, tema, volume, acessibilidade } = req.body;
    const sql = 'UPDATE configuracoes SET id_usuario = ?, tema = ?, volume = ?, acessibilidade = ? WHERE id_conf = ?';
    db.query(sql, [id_usuario, tema, volume, acessibilidade, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Configuração atualizada com sucesso' });
    });
});

// DELETE - Remover configuração
router.delete('/configuracoes/:id', (req, res) => {
    db.query('DELETE FROM configuracoes WHERE id_conf = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Configuração deletada com sucesso' });
    });
});

module.exports = router;