const express = require('express');
const router = express.Router();
const db = require('../config/db');

// CREATE - Criar novo responsável
router.post('/responsaveis', (req, res) => {
    console.log('POST/responsavel recebido:', req.body);
     const { nome, email, senha_responsavel } = req.body;
    const sql = 'INSERT INTO responsavel (nome, email, senha_responsavel) VALUES (?, ?, ?)';
    db.query(sql, [nome, email, senha_responsavel], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Responsável criado com sucesso' });
    });
});

// READ - Listar todos os responsáveis
router.get('/responsaveis', (req, res) => {
    db.query('SELECT * FROM responsavel', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// READ - Obter responsável por ID
router.get('/responsaveis/:id', (req, res) => {
    db.query('SELECT * FROM responsavel WHERE id_responsavel = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Responsável não encontrado' });
        res.json(result[0]);
    });
});

// UPDATE - Atualizar responsável
router.put('/responsaveis/:id', (req, res) => {
    const { nome, email, senha_responsavel } = req.body;
    const sql = 'UPDATE responsavel SET nome = ?, email = ?, senha_responsavel = ? WHERE id_responsavel = ?';
    db.query(sql, [nome, email, senha_responsavel, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Responsável atualizado com sucesso' });
    });
});

// DELETE - Remover responsável
router.delete('/responsaveis/:id', (req, res) => {
    db.query('DELETE FROM responsavel WHERE id_responsavel = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Responsável deletado com sucesso' });
    });
});

module.exports = router;