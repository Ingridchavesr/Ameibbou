const express = require('express');
const router = express.Router();
const db = require('../config/db');

// CREATE - Criar novo jogo
router.post('/jogos', (req, res) => {
    const { nome, descricao } = req.body;
    const sql = 'INSERT INTO jogos (nome, descricao) VALUES (?, ?)';
    db.query(sql, [nome, descricao], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Jogo criado com sucesso' });
    });
});

// READ - Listar todos os jogos
router.get('/jogos', (req, res) => {
    db.query('SELECT * FROM jogos', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// READ - Obter um jogo por ID
router.get('/jogos/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM jogos WHERE id_jogo = ?', [id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Jogo não encontrado' });
        res.json(result[0]);
    });
});

// UPDATE - Atualizar dados de um jogo
router.put('/jogos/:id', (req, res) => {
    const { nome, descricao } = req.body;
    const id = req.params.id;
    const sql = 'UPDATE jogos SET nome = ?, descricao = ? WHERE id_jogo = ?';
    db.query(sql, [nome, descricao, id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Jogo atualizado com sucesso' });
    });
});

// DELETE - Remover um jogo
router.delete('/jogos/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM jogos WHERE id_jogo = ?', [id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Jogo deletado com sucesso' });
    });
});

module.exports = router;