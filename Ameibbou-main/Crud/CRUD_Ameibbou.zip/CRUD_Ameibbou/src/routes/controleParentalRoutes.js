const express = require('express');
const router = express.Router();
const db = require('../config/db');

// CREATE - Criar novo controle parental
router.post('/controle_parental', (req, res) => {
    const { id_usuario, relatorios, tempo_uso, permissoes } = req.body;
    const sql = 'INSERT INTO controle_parental (id_usuario, relatorios, tempo_uso, permissoes) VALUES (?, ?, ?, ?)';
    db.query(sql, [id_usuario, relatorios, tempo_uso, permissoes], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Controle parental criado com sucesso' });
    });
});

// READ - Listar todos os controles parentais
router.get('/controle_parental', (req, res) => {
    db.query('SELECT * FROM controle_parental', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// READ - Buscar controle parental por ID
router.get('/controle_parental/:id', (req, res) => {
    db.query('SELECT * FROM controle_parental WHERE id_controle = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Controle parental não encontrado' });
        res.json(result[0]);
    });
});

// UPDATE - Atualizar controle parental
router.put('/controle_parental/:id', (req, res) => {
    const { id_usuario, relatorios, tempo_uso, permissoes } = req.body;
    const sql = 'UPDATE controle_parental SET id_usuario = ?, relatorios = ?, tempo_uso = ?, permissoes = ? WHERE id_controle = ?';
    db.query(sql, [id_usuario, relatorios, tempo_uso, permissoes, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Controle parental atualizado com sucesso' });
    });
});

// DELETE - Remover controle parental
router.delete('/controle_parental/:id', (req, res) => {
    db.query('DELETE FROM controle_parental WHERE id_controle = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Controle parental deletado com sucesso' });
    });
});

module.exports = router;