const express = require('express');
const router = express.Router();
const db = require('../config/db');

// CREATE - Criar novo progresso de jogo
router.post('/progresso_jogo', (req, res) => {
    const { id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada } = req.body;
    const sql = 'INSERT INTO progresso_jogo (id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: result.insertId, message: 'Progresso de jogo criado com sucesso' });
    });
});

// READ - Listar todos os progressos
router.get('/progresso_jogo', (req, res) => {
    db.query('SELECT * FROM progresso_jogo', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// READ - Obter progresso por ID
router.get('/progresso_jogo/:id', (req, res) => {
    db.query('SELECT * FROM progresso_jogo WHERE id_progresso = ?', [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);
        if (result.length === 0) return res.status(404).json({ message: 'Progresso não encontrado' });
        res.json(result[0]);
    });
});

// UPDATE - Atualizar progresso
router.put('/progresso_jogo/:id', (req, res) => {
    const { id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada } = req.body;
    const sql = 'UPDATE progresso_jogo SET id_usuario = ?, id_jogo = ?, nivel_atual = ?, pontuacao = ?, ultima_jogada = ? WHERE id_progresso = ?';
    db.query(sql, [id_usuario, id_jogo, nivel_atual, pontuacao, ultima_jogada, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Progresso atualizado com sucesso' });
    });
});

// DELETE - Remover progresso
router.delete('/progresso_jogo/:id', (req, res) => {
    db.query('DELETE FROM progresso_jogo WHERE id_progresso = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Progresso deletado com sucesso' });
    });
});

module.exports = router;