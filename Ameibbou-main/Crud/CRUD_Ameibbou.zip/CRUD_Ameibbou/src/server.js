const express = require('express');
const bodyParser = require('body-parser');

const usuarioRoutes = require('./routes/usuarioRoutes');
const responsavelRoutes = require('./routes/responsavelRoutes');
const jogosRoutes = require('./routes/jogosRoutes');
const usuarioPersonagemRoutes = require('./routes/usuarioPersonagemRoutes');
const progressoJogoRoutes = require('./routes/progressoJogoRoutes');
const conteudoEducacionalRoutes = require('./routes/conteudoEducacionalRoutes');
const configuracoesRoutes = require('./routes/configuracoesRoutes');
const controleParentalRoutes = require('./routes/controleParentalRoutes');

const app = express();
app.use(bodyParser.json());

app.use('/api', usuarioRoutes);
app.use('/api', responsavelRoutes);
app.use('/api', jogosRoutes);
app.use('/api', usuarioPersonagemRoutes);
app.use('/api', progressoJogoRoutes);
app.use('/api', conteudoEducacionalRoutes);
app.use('/api', configuracoesRoutes);
app.use('/api', controleParentalRoutes);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});